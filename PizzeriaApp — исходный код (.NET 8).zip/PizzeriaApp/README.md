# PizzeriaApp — информационная система «Пиццерия»

Учебный проект по ПМ.02 (студент Мещеряков М. Н., группа 3ИП-9-24).
Многослойная архитектура: `PizzeriaApp.DataAccess` (сущности, JSON-репозитории) →
`PizzeriaApp.BusinessLogic` (сервисы Menu / Customers / Orders / Reports, исключения) →
`PizzeriaApp.Presentation` (консольный интерфейс, DI). Тесты — `tests/PizzeriaApp.Tests` (xUnit).

## Требования
.NET SDK 8.0 (https://dotnet.microsoft.com/download). Доступ к nuget.org при первой сборке.

## Запуск
```bash
dotnet build PizzeriaApp.sln
dotnet run --project src/PizzeriaApp.Presentation            # интерактивное меню
dotnet run --project src/PizzeriaApp.Presentation -- --demo  # сквозной сценарий без ввода
dotnet test PizzeriaApp.sln                                  # автотесты
dotnet test PizzeriaApp.sln --collect:"XPlat Code Coverage"  # тесты + покрытие (coverlet)
```
Данные хранятся в `bin/.../data/*.json`, журнал Trace — в `bin/.../logs/pizzeria.log`.
