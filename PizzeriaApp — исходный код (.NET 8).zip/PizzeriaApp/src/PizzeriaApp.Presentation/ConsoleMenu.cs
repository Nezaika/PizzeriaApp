using System.Globalization;
using PizzeriaApp.BusinessLogic.Exceptions;
using PizzeriaApp.BusinessLogic.Interfaces;
using PizzeriaApp.DataAccess.Entities;

namespace PizzeriaApp.Presentation;

/// <summary>Консольный интерфейс пользователя (слой представления).</summary>
public class ConsoleMenu
{
    private readonly IMenuService _menu;
    private readonly ICustomerService _customers;
    private readonly IOrderService _orders;
    private readonly IReportService _reports;
    private readonly Dictionary<string, Action> _actions;

    public ConsoleMenu(IMenuService menu, ICustomerService customers, IOrderService orders, IReportService reports)
    {
        _menu = menu;
        _customers = customers;
        _orders = orders;
        _reports = reports;
        _actions = new Dictionary<string, Action>
        {
            ["1"] = PrintMenu,
            ["2"] = AddPizza,
            ["3"] = SearchPizza,
            ["4"] = RegisterCustomer,
            ["5"] = CreateOrder,
            ["6"] = ChangeStatus,
            ["7"] = PrintOrders,
            ["8"] = PrintReports
        };
    }

    public void RunInteractive()
    {
        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("=== ПИЦЦЕРИЯ: учёт заказов ===");
            Console.WriteLine("1. Показать меню          5. Создать заказ");
            Console.WriteLine("2. Добавить пиццу         6. Изменить статус заказа");
            Console.WriteLine("3. Поиск пиццы            7. Список заказов");
            Console.WriteLine("4. Зарегистрировать клиента  8. Отчёты");
            Console.WriteLine("0. Выход");
            Console.Write("Выбор: ");
            string choice = Console.ReadLine()?.Trim() ?? string.Empty;
            if (choice == "0")
            {
                return;
            }

            Safe(() => Dispatch(choice));
        }
    }

    /// <summary>Сквозной сценарий без участия пользователя — используется для проверки интеграции модулей.</summary>
    public int RunDemoScenario()
    {
        Console.WriteLine("--- Демонстрационный сценарий ---");
        PrintMenu();
        var customer = _customers.GetAll()[0];
        var order = _orders.CreateOrder(customer.Id, new[] { new OrderLine(1, 2), new OrderLine(2, 1) }, isDelivery: true);
        PrintOrder(order);
        _orders.ChangeStatus(order.Id, OrderStatus.Cooking);
        _orders.ChangeStatus(order.Id, OrderStatus.Delivering);
        order = _orders.ChangeStatus(order.Id, OrderStatus.Completed);
        Console.WriteLine($"Заказ №{order.Id} доведён до статуса {order.Status}");

        Console.WriteLine("Негативная проверка: отмена завершённого заказа");
        Safe(() => _orders.Cancel(order.Id));
        Console.WriteLine("Негативная проверка: заказ пиццы с несуществующим Id");
        Safe(() => _orders.CreateOrder(customer.Id, new[] { new OrderLine(999, 1) }, false));

        PrintReports();
        return 0;
    }

    private void Dispatch(string choice)
    {
        if (_actions.TryGetValue(choice, out var action))
        {
            action();
        }
        else
        {
            Console.WriteLine("Неизвестный пункт меню.");
        }
    }

    private void PrintMenu()
    {
        Console.WriteLine("Меню:");
        foreach (var pizza in _menu.GetMenu())
        {
            Console.WriteLine("  " + pizza);
        }
    }

    private void AddPizza()
    {
        string name = Ask("Название");
        var size = Enum.Parse<PizzaSize>(Ask("Размер (Small/Medium/Large)"), ignoreCase: true);
        decimal price = ReadDecimal("Цена");
        Console.WriteLine("Добавлено: " + _menu.AddPizza(name, size, price));
    }

    private void SearchPizza()
    {
        var found = _menu.Search(Ask("Часть названия"));
        Console.WriteLine(found.Count == 0 ? "Ничего не найдено." : string.Join(Environment.NewLine, found));
    }

    private void RegisterCustomer()
    {
        var customer = _customers.Register(Ask("ФИО"), Ask("Телефон"), Ask("Адрес"));
        Console.WriteLine("Зарегистрирован: " + customer);
    }

    private void CreateOrder()
    {
        int customerId = ReadInt("Id клиента");
        bool delivery = Ask("Доставка? (y/n)").Equals("y", StringComparison.OrdinalIgnoreCase);
        var lines = new List<OrderLine>();
        while (true)
        {
            int pizzaId = ReadInt("Id пиццы (0 — закончить)");
            if (pizzaId == 0)
            {
                break;
            }

            lines.Add(new OrderLine(pizzaId, ReadInt("Количество")));
        }

        PrintOrder(_orders.CreateOrder(customerId, lines, delivery));
    }

    private void ChangeStatus()
    {
        int id = ReadInt("Id заказа");
        var status = Enum.Parse<OrderStatus>(Ask("Новый статус (Cooking/Delivering/Completed/Cancelled)"), ignoreCase: true);
        PrintOrder(_orders.ChangeStatus(id, status));
    }

    private void PrintOrders()
    {
        foreach (var order in _orders.GetAll())
        {
            Console.WriteLine($"  №{order.Id} от {order.CreatedAt:dd.MM.yyyy HH:mm}, клиент {order.CustomerId}, {order.Status}, итого {order.Total:0.00} руб.");
        }
    }

    private void PrintReports()
    {
        var from = DateTime.Today.AddMonths(-1);
        var to = DateTime.Now;
        Console.WriteLine($"Выручка за месяц (завершённые заказы): {_reports.GetRevenue(from, to):0.00} руб.");
        Console.WriteLine("Топ пицц:");
        foreach (var line in _reports.GetTopPizzas(from, to))
        {
            Console.WriteLine($"  {line.PizzaName}: {line.Quantity} шт., {line.Revenue:0.00} руб.");
        }

        Console.WriteLine("Заказы по статусам:");
        foreach (var pair in _reports.GetOrdersByStatus())
        {
            Console.WriteLine($"  {pair.Key}: {pair.Value}");
        }
    }

    private static void PrintOrder(Order order)
    {
        Console.WriteLine($"Заказ №{order.Id} [{order.Status}] доставка: {(order.IsDelivery ? "да" : "нет")}");
        foreach (var item in order.Items)
        {
            Console.WriteLine($"  {item.PizzaName} x{item.Quantity} = {item.LineTotal:0.00}");
        }

        Console.WriteLine($"  Подытог {order.Subtotal:0.00}, скидка {order.Discount:0.00}, доставка {order.DeliveryFee:0.00}, ИТОГО {order.Total:0.00} руб.");
    }

    private static void Safe(Action action)
    {
        try
        {
            action();
        }
        catch (PizzeriaException ex)
        {
            Console.WriteLine("Ошибка: " + ex.Message);
        }
        catch (Exception ex) when (ex is FormatException or ArgumentException)
        {
            Console.WriteLine("Некорректный ввод: " + ex.Message);
        }
    }

    private static string Ask(string prompt)
    {
        Console.Write(prompt + ": ");
        return Console.ReadLine()?.Trim() ?? string.Empty;
    }

    private static int ReadInt(string prompt) => int.Parse(Ask(prompt), CultureInfo.InvariantCulture);

    private static decimal ReadDecimal(string prompt) => decimal.Parse(Ask(prompt).Replace(',', '.'), CultureInfo.InvariantCulture);
}
