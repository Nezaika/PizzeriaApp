using System.Diagnostics;
using Microsoft.Extensions.DependencyInjection;
using PizzeriaApp.BusinessLogic.Interfaces;
using PizzeriaApp.BusinessLogic.Services;
using PizzeriaApp.DataAccess.Repositories;

namespace PizzeriaApp.Presentation;

/// <summary>Точка входа: композиция слоёв (DI), настройка журнала Trace, запуск консольного меню.</summary>
public static class Program
{
    public static int Main(string[] args)
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        string baseDir = AppContext.BaseDirectory;
        string dataDir = Path.Combine(baseDir, "data");
        string logDir = Path.Combine(baseDir, "logs");
        Directory.CreateDirectory(logDir);

        Trace.Listeners.Add(new TextWriterTraceListener(Path.Combine(logDir, "pizzeria.log")));
        Trace.AutoFlush = true;
        Trace.WriteLine($"=== Запуск PizzeriaApp {DateTime.Now:dd.MM.yyyy HH:mm:ss} ===");

        using var provider = ConfigureServices(dataDir);
        var seeder = new DataSeeder(provider.GetRequiredService<IMenuService>(), provider.GetRequiredService<ICustomerService>());
        seeder.SeedIfEmpty();

        var ui = new ConsoleMenu(
            provider.GetRequiredService<IMenuService>(),
            provider.GetRequiredService<ICustomerService>(),
            provider.GetRequiredService<IOrderService>(),
            provider.GetRequiredService<IReportService>());

        if (args.Contains("--demo"))
        {
            return ui.RunDemoScenario();
        }

        ui.RunInteractive();
        return 0;
    }

    /// <summary>Регистрация зависимостей: интерфейсы BLL → реализации, интерфейсы DAL → JSON-репозитории.</summary>
    public static ServiceProvider ConfigureServices(string dataDir)
    {
        var services = new ServiceCollection();
        services.AddSingleton<IPizzaRepository>(_ => new PizzaRepository(dataDir));
        services.AddSingleton<ICustomerRepository>(_ => new CustomerRepository(dataDir));
        services.AddSingleton<IOrderRepository>(_ => new OrderRepository(dataDir));
        services.AddSingleton<IMenuService, MenuService>();
        services.AddSingleton<ICustomerService, CustomerService>();
        services.AddSingleton<IOrderService, OrderService>();
        services.AddSingleton<IReportService, ReportService>();
        return services.BuildServiceProvider();
    }
}
