using PizzeriaApp.BusinessLogic.Interfaces;
using PizzeriaApp.DataAccess.Entities;

namespace PizzeriaApp.Presentation;

/// <summary>Заполняет пустое хранилище стартовыми данными (меню и один клиент).</summary>
public class DataSeeder
{
    private readonly IMenuService _menu;
    private readonly ICustomerService _customers;

    public DataSeeder(IMenuService menu, ICustomerService customers)
    {
        _menu = menu;
        _customers = customers;
    }

    public void SeedIfEmpty()
    {
        if (_menu.GetMenu().Count == 0)
        {
            _menu.AddPizza("Маргарита", PizzaSize.Medium, 450m);
            _menu.AddPizza("Пепперони", PizzaSize.Medium, 590m);
            _menu.AddPizza("Четыре сыра", PizzaSize.Large, 790m);
            _menu.AddPizza("Гавайская", PizzaSize.Small, 420m);
            _menu.AddPizza("Мясная", PizzaSize.Large, 890m);
        }

        if (_customers.GetAll().Count == 0)
        {
            _customers.Register("Иванов Иван Иванович", "+7 (916) 123-45-67", "ул. Ленина, д. 10, кв. 5");
        }
    }
}
