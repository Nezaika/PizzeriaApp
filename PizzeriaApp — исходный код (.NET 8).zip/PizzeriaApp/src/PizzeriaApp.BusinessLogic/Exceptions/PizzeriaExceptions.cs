namespace PizzeriaApp.BusinessLogic.Exceptions;

/// <summary>Базовое исключение бизнес-логики пиццерии.</summary>
public class PizzeriaException : Exception
{
    public PizzeriaException() : base("Ошибка бизнес-логики.") { }

    public PizzeriaException(string message) : base(message) { }

    public PizzeriaException(string message, Exception innerException) : base(message, innerException) { }
}

/// <summary>Нарушение правил валидации входных данных.</summary>
public class ValidationException : PizzeriaException
{
    public ValidationException() : base("Некорректные входные данные.") { }

    public ValidationException(string message) : base(message) { }

    public ValidationException(string message, Exception innerException) : base(message, innerException) { }
}

/// <summary>Сущность не найдена в хранилище.</summary>
public class EntityNotFoundException : PizzeriaException
{
    public EntityNotFoundException() : base("Объект не найден.") { }

    public EntityNotFoundException(string message) : base(message) { }

    public EntityNotFoundException(string message, Exception innerException) : base(message, innerException) { }

    public EntityNotFoundException(string entityName, int id)
        : base($"{entityName} с идентификатором {id} не найден(а).") { }
}

/// <summary>Попытка заказать пиццу, которой нет в наличии.</summary>
public class PizzaUnavailableException : PizzeriaException
{
    public PizzaUnavailableException() : base("Пицца отсутствует в меню.") { }

    public PizzaUnavailableException(string message) : base(message) { }

    public PizzaUnavailableException(string message, Exception innerException) : base(message, innerException) { }

    public static PizzaUnavailableException ForPizza(string pizza) => new($"Пицца «{pizza}» временно отсутствует в меню.");
}

/// <summary>Недопустимый переход статуса заказа.</summary>
public class InvalidOrderStateException : PizzeriaException
{
    public InvalidOrderStateException() : base("Недопустимый переход статуса заказа.") { }

    public InvalidOrderStateException(string message) : base(message) { }

    public InvalidOrderStateException(string message, Exception innerException) : base(message, innerException) { }

    public static InvalidOrderStateException ForTransition(string current, string target) =>
        new($"Переход заказа из статуса «{current}» в «{target}» недопустим.");
}
