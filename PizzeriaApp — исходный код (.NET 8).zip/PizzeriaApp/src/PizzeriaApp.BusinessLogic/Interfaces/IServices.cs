using PizzeriaApp.DataAccess.Entities;

namespace PizzeriaApp.BusinessLogic.Interfaces;

/// <summary>Модуль Menu — управление меню пиццерии.</summary>
public interface IMenuService
{
    IReadOnlyList<Pizza> GetMenu(bool onlyAvailable = false);
    IReadOnlyList<Pizza> Search(string namePart);
    Pizza AddPizza(string name, PizzaSize size, decimal price);
    void SetAvailability(int pizzaId, bool isAvailable);
    void ChangePrice(int pizzaId, decimal newPrice);
}

/// <summary>Модуль Customers — учёт клиентов.</summary>
public interface ICustomerService
{
    IReadOnlyList<Customer> GetAll();
    Customer Register(string fullName, string phone, string address);
    Customer GetById(int customerId);
}

/// <summary>Строка заказа, передаваемая из UI в сервис.</summary>
public record OrderLine(int PizzaId, int Quantity);

/// <summary>Модуль Orders — оформление и сопровождение заказов.</summary>
public interface IOrderService
{
    Order CreateOrder(int customerId, IReadOnlyCollection<OrderLine> lines, bool isDelivery);
    Order ChangeStatus(int orderId, OrderStatus newStatus);
    Order Cancel(int orderId);
    IReadOnlyList<Order> GetAll();
    Order GetById(int orderId);
}

/// <summary>Строка отчёта о продажах по пиццам.</summary>
public record SalesLine(string PizzaName, int Quantity, decimal Revenue);

/// <summary>Модуль Reports — отчётность.</summary>
public interface IReportService
{
    decimal GetRevenue(DateTime periodStart, DateTime periodEnd);
    IReadOnlyList<SalesLine> GetTopPizzas(DateTime periodStart, DateTime periodEnd, int top = 5);
    IReadOnlyDictionary<OrderStatus, int> GetOrdersByStatus();
}
