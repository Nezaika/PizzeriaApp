using System.Text.RegularExpressions;
using PizzeriaApp.BusinessLogic.Exceptions;
using PizzeriaApp.BusinessLogic.Interfaces;
using PizzeriaApp.DataAccess.Entities;
using PizzeriaApp.DataAccess.Repositories;

namespace PizzeriaApp.BusinessLogic.Services;

/// <inheritdoc cref="ICustomerService"/>
public partial class CustomerService : ICustomerService
{
    private readonly ICustomerRepository _customers;

    public CustomerService(ICustomerRepository customers)
    {
        _customers = customers ?? throw new ArgumentNullException(nameof(customers));
    }

    public IReadOnlyList<Customer> GetAll() => _customers.GetAll();

    public Customer Register(string fullName, string phone, string address)
    {
        if (string.IsNullOrWhiteSpace(fullName))
        {
            throw new ValidationException("Имя клиента обязательно.");
        }

        string normalizedPhone = NormalizePhone(phone);
        if (_customers.FindByPhone(normalizedPhone) is not null)
        {
            throw new ValidationException($"Клиент с телефоном {normalizedPhone} уже зарегистрирован.");
        }

        return _customers.Add(new Customer
        {
            FullName = fullName.Trim(),
            Phone = normalizedPhone,
            Address = address?.Trim() ?? string.Empty
        });
    }

    public Customer GetById(int customerId) =>
        _customers.GetById(customerId) ?? throw new EntityNotFoundException("Клиент", customerId);

    /// <summary>Приводит телефон к виду +7XXXXXXXXXX; принимает форматы 8XXXXXXXXXX и +7XXXXXXXXXX.</summary>
    public static string NormalizePhone(string? phone)
    {
        string digits = DigitsOnly().Replace(phone ?? string.Empty, string.Empty);
        if (digits.Length == 11 && (digits[0] == '7' || digits[0] == '8'))
        {
            return "+7" + digits[1..];
        }

        throw new ValidationException("Телефон должен содержать 11 цифр и начинаться с 8 или +7.");
    }

    [GeneratedRegex(@"\D")]
    private static partial Regex DigitsOnly();
}
