using System.Diagnostics;
using PizzeriaApp.BusinessLogic.Exceptions;
using PizzeriaApp.BusinessLogic.Interfaces;
using PizzeriaApp.DataAccess.Entities;
using PizzeriaApp.DataAccess.Repositories;

namespace PizzeriaApp.BusinessLogic.Services;

/// <inheritdoc cref="IOrderService"/>
public class OrderService : IOrderService
{
    public const int MaxQuantityPerLine = 20;
    public const decimal DiscountThreshold = 2000m;
    public const decimal DiscountRate = 0.10m;
    public const decimal FreeDeliveryThreshold = 1500m;
    public const decimal DeliveryFee = 150m;

    private static readonly IReadOnlyDictionary<OrderStatus, OrderStatus[]> AllowedTransitions =
        new Dictionary<OrderStatus, OrderStatus[]>
        {
            [OrderStatus.New] = new[] { OrderStatus.Cooking, OrderStatus.Cancelled },
            [OrderStatus.Cooking] = new[] { OrderStatus.Delivering, OrderStatus.Completed, OrderStatus.Cancelled },
            [OrderStatus.Delivering] = new[] { OrderStatus.Completed },
            [OrderStatus.Completed] = Array.Empty<OrderStatus>(),
            [OrderStatus.Cancelled] = Array.Empty<OrderStatus>()
        };

    private readonly IOrderRepository _orders;
    private readonly IPizzaRepository _pizzas;
    private readonly ICustomerRepository _customers;

    public OrderService(IOrderRepository orders, IPizzaRepository pizzas, ICustomerRepository customers)
    {
        _orders = orders ?? throw new ArgumentNullException(nameof(orders));
        _pizzas = pizzas ?? throw new ArgumentNullException(nameof(pizzas));
        _customers = customers ?? throw new ArgumentNullException(nameof(customers));
    }

    public Order CreateOrder(int customerId, IReadOnlyCollection<OrderLine> lines, bool isDelivery)
    {
        ArgumentNullException.ThrowIfNull(lines);
        var customer = _customers.GetById(customerId) ?? throw new EntityNotFoundException("Клиент", customerId);
        if (lines.Count == 0)
        {
            throw new ValidationException("Заказ должен содержать хотя бы одну позицию.");
        }

        if (isDelivery && string.IsNullOrWhiteSpace(customer.Address))
        {
            throw new ValidationException("Для доставки у клиента должен быть указан адрес.");
        }

        var order = new Order { CustomerId = customerId, CreatedAt = DateTime.Now, IsDelivery = isDelivery };
        foreach (var line in lines)
        {
            order.Items.Add(BuildItem(line));
        }

        CalculateTotals(order);
        _orders.Add(order);
        Trace.WriteLine($"[BLL] Создан заказ №{order.Id} для клиента {customerId}, сумма {order.Total:0.00}");
        return order;
    }

    public Order ChangeStatus(int orderId, OrderStatus newStatus)
    {
        var order = GetById(orderId);
        if (!AllowedTransitions[order.Status].Contains(newStatus))
        {
            throw InvalidOrderStateException.ForTransition(order.Status.ToString(), newStatus.ToString());
        }

        if (newStatus == OrderStatus.Delivering && !order.IsDelivery)
        {
            throw InvalidOrderStateException.ForTransition(order.Status.ToString(), "Delivering (заказ без доставки)");
        }

        Debug.WriteLine($"[BLL] Заказ №{orderId}: {order.Status} -> {newStatus}");
        order.Status = newStatus;
        _orders.Update(order);
        return order;
    }

    public Order Cancel(int orderId) => ChangeStatus(orderId, OrderStatus.Cancelled);

    public IReadOnlyList<Order> GetAll() => _orders.GetAll();

    public Order GetById(int orderId) =>
        _orders.GetById(orderId) ?? throw new EntityNotFoundException("Заказ", orderId);

    /// <summary>Рассчитывает подытог, скидку, стоимость доставки и итог заказа.</summary>
    public static void CalculateTotals(Order order)
    {
        ArgumentNullException.ThrowIfNull(order);
        order.Subtotal = order.Items.Sum(i => i.LineTotal);
        order.Discount = order.Subtotal >= DiscountThreshold ? Math.Round(order.Subtotal * DiscountRate, 2) : 0m;
        order.DeliveryFee = order.IsDelivery && order.Subtotal < FreeDeliveryThreshold ? DeliveryFee : 0m;
        order.Total = order.Subtotal - order.Discount + order.DeliveryFee;
    }

    private OrderItem BuildItem(OrderLine line)
    {
        if (line.Quantity < 1 || line.Quantity > MaxQuantityPerLine)
        {
            throw new ValidationException($"Количество в строке должно быть от 1 до {MaxQuantityPerLine}.");
        }

        var pizza = _pizzas.GetById(line.PizzaId) ?? throw new EntityNotFoundException("Пицца", line.PizzaId);
        if (!pizza.IsAvailable)
        {
            throw PizzaUnavailableException.ForPizza(pizza.Name);
        }

        return new OrderItem { PizzaId = pizza.Id, PizzaName = pizza.Name, Quantity = line.Quantity, UnitPrice = pizza.Price };
    }
}
