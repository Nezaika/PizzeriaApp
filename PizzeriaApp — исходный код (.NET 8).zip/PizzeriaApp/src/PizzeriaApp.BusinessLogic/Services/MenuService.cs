using System.Diagnostics;
using PizzeriaApp.BusinessLogic.Exceptions;
using PizzeriaApp.BusinessLogic.Interfaces;
using PizzeriaApp.DataAccess.Entities;
using PizzeriaApp.DataAccess.Repositories;

namespace PizzeriaApp.BusinessLogic.Services;

/// <inheritdoc cref="IMenuService"/>
public class MenuService : IMenuService
{
    public const decimal MinPrice = 100m;
    public const decimal MaxPrice = 5000m;

    private readonly IPizzaRepository _pizzas;

    public MenuService(IPizzaRepository pizzas)
    {
        _pizzas = pizzas ?? throw new ArgumentNullException(nameof(pizzas));
    }

    public IReadOnlyList<Pizza> GetMenu(bool onlyAvailable = false)
    {
        var all = _pizzas.GetAll();
        return onlyAvailable ? all.Where(p => p.IsAvailable).ToList() : all;
    }

    public IReadOnlyList<Pizza> Search(string namePart)
    {
        if (string.IsNullOrWhiteSpace(namePart))
        {
            throw new ValidationException("Строка поиска не может быть пустой.");
        }

        return _pizzas.FindByName(namePart.Trim());
    }

    public Pizza AddPizza(string name, PizzaSize size, decimal price)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            throw new ValidationException("Название пиццы обязательно.");
        }

        ValidatePrice(price);
        if (_pizzas.GetAll().Any(p => p.Name.Equals(name.Trim(), StringComparison.OrdinalIgnoreCase) && p.Size == size))
        {
            throw new ValidationException($"Пицца «{name}» размера {(int)size} см уже есть в меню.");
        }

        var pizza = _pizzas.Add(new Pizza { Name = name.Trim(), Size = size, Price = price });
        Trace.WriteLine($"[BLL] Добавлена пицца {pizza}");
        return pizza;
    }

    public void SetAvailability(int pizzaId, bool isAvailable)
    {
        var pizza = GetPizzaOrThrow(pizzaId);
        pizza.IsAvailable = isAvailable;
        _pizzas.Update(pizza);
    }

    public void ChangePrice(int pizzaId, decimal newPrice)
    {
        ValidatePrice(newPrice);
        var pizza = GetPizzaOrThrow(pizzaId);
        pizza.Price = newPrice;
        _pizzas.Update(pizza);
    }

    private static void ValidatePrice(decimal price)
    {
        if (price < MinPrice || price > MaxPrice)
        {
            throw new ValidationException($"Цена должна быть в диапазоне от {MinPrice} до {MaxPrice} руб.");
        }
    }

    private Pizza GetPizzaOrThrow(int pizzaId) =>
        _pizzas.GetById(pizzaId) ?? throw new EntityNotFoundException("Пицца", pizzaId);
}
