using PizzeriaApp.BusinessLogic.Interfaces;
using PizzeriaApp.DataAccess.Entities;
using PizzeriaApp.DataAccess.Repositories;

namespace PizzeriaApp.BusinessLogic.Services;

/// <inheritdoc cref="IReportService"/>
public class ReportService : IReportService
{
    private readonly IOrderRepository _orders;

    public ReportService(IOrderRepository orders)
    {
        _orders = orders ?? throw new ArgumentNullException(nameof(orders));
    }

    public decimal GetRevenue(DateTime periodStart, DateTime periodEnd) =>
        CompletedInPeriod(periodStart, periodEnd).Sum(o => o.Total);

    public IReadOnlyList<SalesLine> GetTopPizzas(DateTime periodStart, DateTime periodEnd, int top = 5) =>
        CompletedInPeriod(periodStart, periodEnd)
            .SelectMany(o => o.Items)
            .GroupBy(i => i.PizzaName)
            .Select(g => new SalesLine(g.Key, g.Sum(i => i.Quantity), g.Sum(i => i.LineTotal)))
            .OrderByDescending(s => s.Quantity)
            .Take(top)
            .ToList();

    public IReadOnlyDictionary<OrderStatus, int> GetOrdersByStatus() =>
        _orders.GetAll().GroupBy(o => o.Status).ToDictionary(g => g.Key, g => g.Count());

    private IEnumerable<Order> CompletedInPeriod(DateTime periodStart, DateTime periodEnd) =>
        _orders.GetByPeriod(periodStart, periodEnd).Where(o => o.Status == OrderStatus.Completed);
}
