namespace PizzeriaApp.DataAccess.Entities;

/// <summary>Базовый контракт сущности с целочисленным идентификатором.</summary>
public interface IEntity
{
    int Id { get; set; }
}
