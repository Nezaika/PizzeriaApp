namespace PizzeriaApp.DataAccess.Entities;

/// <summary>Статус заказа. Переходы: New → Cooking → Delivering → Completed; отмена возможна из New и Cooking.</summary>
public enum OrderStatus
{
    New,
    Cooking,
    Delivering,
    Completed,
    Cancelled
}

/// <summary>Строка заказа.</summary>
public class OrderItem
{
    public int PizzaId { get; set; }
    public string PizzaName { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public decimal UnitPrice { get; set; }
    public decimal LineTotal => Quantity * UnitPrice;
}

/// <summary>Заказ клиента.</summary>
public class Order : IEntity
{
    public int Id { get; set; }
    public int CustomerId { get; set; }
    public DateTime CreatedAt { get; set; }
    public bool IsDelivery { get; set; }
    public OrderStatus Status { get; set; } = OrderStatus.New;
    public List<OrderItem> Items { get; set; } = new();
    public decimal Subtotal { get; set; }
    public decimal Discount { get; set; }
    public decimal DeliveryFee { get; set; }
    public decimal Total { get; set; }
}
