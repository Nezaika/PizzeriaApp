namespace PizzeriaApp.DataAccess.Entities;

/// <summary>Клиент пиццерии.</summary>
public class Customer : IEntity
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Address { get; set; } = string.Empty;

    public override string ToString() => $"#{Id} {FullName}, тел. {Phone}, адрес: {Address}";
}
