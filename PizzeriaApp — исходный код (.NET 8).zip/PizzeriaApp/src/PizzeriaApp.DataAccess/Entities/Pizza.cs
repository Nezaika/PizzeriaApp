namespace PizzeriaApp.DataAccess.Entities;

/// <summary>Размер пиццы.</summary>
public enum PizzaSize
{
    Small = 25,
    Medium = 30,
    Large = 35
}

/// <summary>Позиция меню (пицца).</summary>
public class Pizza : IEntity
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public PizzaSize Size { get; set; } = PizzaSize.Medium;
    public decimal Price { get; set; }
    public bool IsAvailable { get; set; } = true;

    public override string ToString() => $"#{Id} {Name} ({(int)Size} см) — {Price:0.00} руб.{(IsAvailable ? string.Empty : " [нет в наличии]")}";
}
