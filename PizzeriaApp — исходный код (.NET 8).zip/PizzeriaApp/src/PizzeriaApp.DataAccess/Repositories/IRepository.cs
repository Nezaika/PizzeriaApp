using PizzeriaApp.DataAccess.Entities;

namespace PizzeriaApp.DataAccess.Repositories;

/// <summary>Контракт репозитория (интерфейс взаимодействия BLL → DAL).</summary>
/// <typeparam name="T">Тип сущности.</typeparam>
public interface IRepository<T>
    where T : class, IEntity
{
    IReadOnlyList<T> GetAll();
    T? GetById(int id);
    T Add(T entity);
    void Update(T entity);
    bool Delete(int id);
}

public interface IPizzaRepository : IRepository<Pizza>
{
    IReadOnlyList<Pizza> FindByName(string namePart);
}

public interface ICustomerRepository : IRepository<Customer>
{
    Customer? FindByPhone(string phone);
}

public interface IOrderRepository : IRepository<Order>
{
    IReadOnlyList<Order> GetByCustomer(int customerId);
    IReadOnlyList<Order> GetByPeriod(DateTime periodStart, DateTime periodEnd);
}
