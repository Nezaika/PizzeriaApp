using System.Diagnostics;
using System.Text.Json;
using System.Text.Json.Serialization;
using PizzeriaApp.DataAccess.Entities;

namespace PizzeriaApp.DataAccess.Repositories;

/// <summary>
/// Универсальный репозиторий с хранением коллекции в JSON-файле.
/// Каждый тип сущности хранится в отдельном файле каталога данных.
/// </summary>
public class JsonRepository<T> : IRepository<T>
    where T : class, IEntity
{
    private static readonly JsonSerializerOptions SerializerOptions = new()
    {
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() }
    };

    private readonly string _filePath;
    private readonly List<T> _items;

    public JsonRepository(string dataDirectory)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(dataDirectory);
        Directory.CreateDirectory(dataDirectory);
        _filePath = Path.Combine(dataDirectory, typeof(T).Name.ToLowerInvariant() + "s.json");
        _items = Load();
        Trace.WriteLine($"[DAL] {typeof(T).Name}: загружено {_items.Count} записей из {_filePath}");
    }

    protected IEnumerable<T> Items => _items;

    public IReadOnlyList<T> GetAll() => _items.ToList();

    public T? GetById(int id) => _items.FirstOrDefault(x => x.Id == id);

    public T Add(T entity)
    {
        ArgumentNullException.ThrowIfNull(entity);
        entity.Id = _items.Count == 0 ? 1 : _items.Max(x => x.Id) + 1;
        _items.Add(entity);
        Save();
        return entity;
    }

    public void Update(T entity)
    {
        ArgumentNullException.ThrowIfNull(entity);
        int index = _items.FindIndex(x => x.Id == entity.Id);
        if (index < 0)
        {
            throw new KeyNotFoundException($"{typeof(T).Name} с Id={entity.Id} не найден.");
        }

        _items[index] = entity;
        Save();
    }

    public bool Delete(int id)
    {
        int removed = _items.RemoveAll(x => x.Id == id);
        if (removed > 0)
        {
            Save();
        }

        return removed > 0;
    }

    private List<T> Load()
    {
        if (!File.Exists(_filePath))
        {
            return new List<T>();
        }

        string json = File.ReadAllText(_filePath);
        return JsonSerializer.Deserialize<List<T>>(json, SerializerOptions) ?? new List<T>();
    }

    private void Save()
    {
        File.WriteAllText(_filePath, JsonSerializer.Serialize(_items, SerializerOptions));
        Debug.WriteLine($"[DAL] {typeof(T).Name}: сохранено {_items.Count} записей");
    }
}

public class PizzaRepository : JsonRepository<Pizza>, IPizzaRepository
{
    public PizzaRepository(string dataDirectory) : base(dataDirectory) { }

    public IReadOnlyList<Pizza> FindByName(string namePart) =>
        Items.Where(p => p.Name.Contains(namePart ?? string.Empty, StringComparison.OrdinalIgnoreCase)).ToList();
}

public class CustomerRepository : JsonRepository<Customer>, ICustomerRepository
{
    public CustomerRepository(string dataDirectory) : base(dataDirectory) { }

    public Customer? FindByPhone(string phone) => Items.FirstOrDefault(c => c.Phone == phone);
}

public class OrderRepository : JsonRepository<Order>, IOrderRepository
{
    public OrderRepository(string dataDirectory) : base(dataDirectory) { }

    public IReadOnlyList<Order> GetByCustomer(int customerId) => Items.Where(o => o.CustomerId == customerId).ToList();

    public IReadOnlyList<Order> GetByPeriod(DateTime periodStart, DateTime periodEnd) =>
        Items.Where(o => o.CreatedAt >= periodStart && o.CreatedAt <= periodEnd).ToList();
}
