using PizzeriaApp.BusinessLogic.Exceptions;
using PizzeriaApp.BusinessLogic.Interfaces;
using PizzeriaApp.BusinessLogic.Services;
using PizzeriaApp.DataAccess.Entities;
using Xunit;

namespace PizzeriaApp.Tests;

public class OrderServiceTests
{
    private readonly InMemoryPizzaRepository _pizzas = new();
    private readonly InMemoryCustomerRepository _customers = new();
    private readonly InMemoryOrderRepository _orders = new();
    private readonly OrderService _service;

    public OrderServiceTests()
    {
        _pizzas.Add(new Pizza { Name = "Маргарита", Price = 450m });
        _pizzas.Add(new Pizza { Name = "Пепперони", Price = 590m });
        _pizzas.Add(new Pizza { Name = "Скрытая", Price = 500m, IsAvailable = false });
        _customers.Add(new Customer { FullName = "Иванов", Phone = "+79161234567", Address = "ул. Ленина, 10" });
        _customers.Add(new Customer { FullName = "Без адреса", Phone = "+79160000000", Address = "" });
        _service = new OrderService(_orders, _pizzas, _customers);
    }

    [Fact] // ТК-14 позитивный
    public void CreateOrder_TwoLines_CalculatesSubtotal()
    {
        var order = _service.CreateOrder(1, new[] { new OrderLine(1, 2), new OrderLine(2, 1) }, false);
        Assert.Equal(1490m, order.Subtotal);
        Assert.Equal(0m, order.Discount);
        Assert.Equal(1490m, order.Total);
        Assert.Equal(OrderStatus.New, order.Status);
    }

    [Fact] // ТК-15 скидка 10 % от 2000
    public void CreateOrder_SubtotalAtThreshold_AppliesDiscount()
    {
        var order = _service.CreateOrder(1, new[] { new OrderLine(1, 2), new OrderLine(2, 2) }, false); // 900 + 1180 = 2080
        Assert.Equal(208m, order.Discount);
        Assert.Equal(1872m, order.Total);
    }

    [Theory] // ТК-16 доставка: платная до 1500, бесплатная от 1500
    [InlineData(1, 150)]   // 450 < 1500
    [InlineData(4, 0)]     // 1800 >= 1500
    public void CreateOrder_Delivery_FeeDependsOnSubtotal(int qty, decimal expectedFee)
    {
        var order = _service.CreateOrder(1, new[] { new OrderLine(1, qty) }, true);
        Assert.Equal(expectedFee, order.DeliveryFee);
    }

    [Fact] // ТК-17 негативный
    public void CreateOrder_EmptyLines_ThrowsValidation() =>
        Assert.Throws<ValidationException>(() => _service.CreateOrder(1, Array.Empty<OrderLine>(), false));

    [Theory] // ТК-18 граничные количества
    [InlineData(0)]
    [InlineData(21)]
    public void CreateOrder_QuantityOutOfRange_ThrowsValidation(int qty) =>
        Assert.Throws<ValidationException>(() => _service.CreateOrder(1, new[] { new OrderLine(1, qty) }, false));

    [Fact] // ТК-19
    public void CreateOrder_UnavailablePizza_ThrowsPizzaUnavailable() =>
        Assert.Throws<PizzaUnavailableException>(() => _service.CreateOrder(1, new[] { new OrderLine(3, 1) }, false));

    [Fact] // ТК-20
    public void CreateOrder_UnknownCustomer_ThrowsNotFound() =>
        Assert.Throws<EntityNotFoundException>(() => _service.CreateOrder(99, new[] { new OrderLine(1, 1) }, false));

    [Fact] // ТК-21
    public void CreateOrder_DeliveryWithoutAddress_ThrowsValidation() =>
        Assert.Throws<ValidationException>(() => _service.CreateOrder(2, new[] { new OrderLine(1, 1) }, true));

    [Fact] // ТК-22 жизненный цикл
    public void ChangeStatus_FullLifecycle_Succeeds()
    {
        var order = _service.CreateOrder(1, new[] { new OrderLine(1, 1) }, true);
        _service.ChangeStatus(order.Id, OrderStatus.Cooking);
        _service.ChangeStatus(order.Id, OrderStatus.Delivering);
        Assert.Equal(OrderStatus.Completed, _service.ChangeStatus(order.Id, OrderStatus.Completed).Status);
    }

    [Fact] // ТК-23 негативный переход
    public void ChangeStatus_NewToCompleted_ThrowsInvalidState()
    {
        var order = _service.CreateOrder(1, new[] { new OrderLine(1, 1) }, false);
        Assert.Throws<InvalidOrderStateException>(() => _service.ChangeStatus(order.Id, OrderStatus.Completed));
    }

    [Fact] // ТК-24 отмена завершённого
    public void Cancel_CompletedOrder_ThrowsInvalidState()
    {
        var order = _service.CreateOrder(1, new[] { new OrderLine(1, 1) }, false);
        _service.ChangeStatus(order.Id, OrderStatus.Cooking);
        _service.ChangeStatus(order.Id, OrderStatus.Completed);
        Assert.Throws<InvalidOrderStateException>(() => _service.Cancel(order.Id));
    }

    [Fact] // ТК-25 Delivering без доставки
    public void ChangeStatus_DeliveringForPickup_ThrowsInvalidState()
    {
        var order = _service.CreateOrder(1, new[] { new OrderLine(1, 1) }, false);
        _service.ChangeStatus(order.Id, OrderStatus.Cooking);
        Assert.Throws<InvalidOrderStateException>(() => _service.ChangeStatus(order.Id, OrderStatus.Delivering));
    }
}
