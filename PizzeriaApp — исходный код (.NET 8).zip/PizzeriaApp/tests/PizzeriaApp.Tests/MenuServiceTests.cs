using PizzeriaApp.BusinessLogic.Exceptions;
using PizzeriaApp.BusinessLogic.Services;
using PizzeriaApp.DataAccess.Entities;
using Xunit;

namespace PizzeriaApp.Tests;

public class MenuServiceTests
{
    private readonly InMemoryPizzaRepository _repo = new();
    private readonly MenuService _service;

    public MenuServiceTests() => _service = new MenuService(_repo);

    [Fact] // ТК-01
    public void AddPizza_ValidData_AppearsInMenu()
    {
        var pizza = _service.AddPizza("Маргарита", PizzaSize.Medium, 450m);
        Assert.Equal(1, pizza.Id);
        Assert.Single(_service.GetMenu());
    }

    [Theory] // ТК-02, ТК-03
    [InlineData(99)]
    [InlineData(5001)]
    public void AddPizza_PriceOutOfRange_ThrowsValidation(decimal price) =>
        Assert.Throws<ValidationException>(() => _service.AddPizza("Тест", PizzaSize.Small, price));

    [Theory] // ТК-04 граничные значения
    [InlineData(100)]
    [InlineData(5000)]
    public void AddPizza_BoundaryPrice_Succeeds(decimal price) =>
        Assert.NotNull(_service.AddPizza("Тест", PizzaSize.Small, price));

    [Fact] // ТК-05
    public void AddPizza_EmptyName_ThrowsValidation() =>
        Assert.Throws<ValidationException>(() => _service.AddPizza("  ", PizzaSize.Small, 300m));

    [Fact] // ТК-06
    public void AddPizza_DuplicateNameAndSize_ThrowsValidation()
    {
        _service.AddPizza("Пепперони", PizzaSize.Large, 600m);
        Assert.Throws<ValidationException>(() => _service.AddPizza("пепперони", PizzaSize.Large, 650m));
    }

    [Fact] // ТК-07
    public void Search_CaseInsensitive_FindsPizza()
    {
        _service.AddPizza("Четыре сыра", PizzaSize.Large, 790m);
        Assert.Single(_service.Search("СЫРА"));
    }

    [Fact] // ТК-08
    public void SetAvailability_UnknownId_ThrowsNotFound() =>
        Assert.Throws<EntityNotFoundException>(() => _service.SetAvailability(42, false));

    [Fact] // ТК-09
    public void GetMenu_OnlyAvailable_FiltersHidden()
    {
        var p = _service.AddPizza("Гавайская", PizzaSize.Small, 420m);
        _service.AddPizza("Мясная", PizzaSize.Large, 890m);
        _service.SetAvailability(p.Id, false);
        Assert.Single(_service.GetMenu(onlyAvailable: true));
    }
}
