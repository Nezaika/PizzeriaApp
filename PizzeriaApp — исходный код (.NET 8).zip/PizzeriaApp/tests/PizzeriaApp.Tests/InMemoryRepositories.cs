using PizzeriaApp.DataAccess.Entities;
using PizzeriaApp.DataAccess.Repositories;

namespace PizzeriaApp.Tests;

/// <summary>Репозиторий в памяти — заглушка DAL для модульных тестов BLL.</summary>
public class InMemoryRepository<T> : IRepository<T>
    where T : class, IEntity
{
    protected List<T> Items { get; } = new();

    public IReadOnlyList<T> GetAll() => Items.ToList();
    public T? GetById(int id) => Items.FirstOrDefault(x => x.Id == id);
    public T Add(T entity)
    {
        entity.Id = Items.Count == 0 ? 1 : Items.Max(x => x.Id) + 1;
        Items.Add(entity);
        return entity;
    }

    public void Update(T entity)
    {
        int i = Items.FindIndex(x => x.Id == entity.Id);
        Items[i] = entity;
    }

    public bool Delete(int id) => Items.RemoveAll(x => x.Id == id) > 0;
}

public class InMemoryPizzaRepository : InMemoryRepository<Pizza>, IPizzaRepository
{
    public IReadOnlyList<Pizza> FindByName(string namePart) =>
        Items.Where(p => p.Name.Contains(namePart, StringComparison.OrdinalIgnoreCase)).ToList();
}

public class InMemoryCustomerRepository : InMemoryRepository<Customer>, ICustomerRepository
{
    public Customer? FindByPhone(string phone) => Items.FirstOrDefault(c => c.Phone == phone);
}

public class InMemoryOrderRepository : InMemoryRepository<Order>, IOrderRepository
{
    public IReadOnlyList<Order> GetByCustomer(int customerId) => Items.Where(o => o.CustomerId == customerId).ToList();
    public IReadOnlyList<Order> GetByPeriod(DateTime periodStart, DateTime periodEnd) => Items.Where(o => o.CreatedAt >= periodStart && o.CreatedAt <= periodEnd).ToList();
}
