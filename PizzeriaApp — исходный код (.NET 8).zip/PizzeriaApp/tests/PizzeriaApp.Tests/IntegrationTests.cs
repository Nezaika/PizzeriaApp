using Microsoft.Extensions.DependencyInjection;
using PizzeriaApp.BusinessLogic.Interfaces;
using PizzeriaApp.DataAccess.Entities;
using PizzeriaApp.DataAccess.Repositories;
using PizzeriaApp.Presentation;
using Xunit;

namespace PizzeriaApp.Tests;

/// <summary>Интеграционные тесты: BLL + DAL (JSON-файлы во временном каталоге) + композиция DI из Presentation.</summary>
public sealed class IntegrationTests : IDisposable
{
    private readonly string _dir = Path.Combine(Path.GetTempPath(), "pizzeria-tests-" + Guid.NewGuid().ToString("N"));

    public void Dispose()
    {
        if (Directory.Exists(_dir))
        {
            Directory.Delete(_dir, true);
        }

        GC.SuppressFinalize(this);
    }

    [Fact] // ИТ-01
    public void JsonRepository_AddThenReload_PersistsData()
    {
        var repo = new PizzaRepository(_dir);
        repo.Add(new Pizza { Name = "Маргарита", Price = 450m });
        var reloaded = new PizzaRepository(_dir);
        Assert.Single(reloaded.GetAll());
        Assert.Equal("Маргарита", reloaded.GetById(1)!.Name);
    }

    [Fact] // ИТ-02 сквозной сценарий через DI
    public void EndToEnd_CreateOrderThroughServices_SavedToJson()
    {
        using var provider = Program.ConfigureServices(_dir);
        new DataSeeder(provider.GetRequiredService<IMenuService>(), provider.GetRequiredService<ICustomerService>()).SeedIfEmpty();
        var orders = provider.GetRequiredService<IOrderService>();

        var order = orders.CreateOrder(1, new[] { new OrderLine(1, 2) }, isDelivery: true);
        orders.ChangeStatus(order.Id, OrderStatus.Cooking);

        var fromDisk = new OrderRepository(_dir).GetById(order.Id);
        Assert.NotNull(fromDisk);
        Assert.Equal(OrderStatus.Cooking, fromDisk!.Status);
        Assert.Equal(1050m, fromDisk.Total); // 900 + доставка 150
        Assert.True(File.Exists(Path.Combine(_dir, "orders.json")));
    }

    [Fact] // ИТ-03 отчёт по данным из файла
    public void Report_AfterCompletedOrder_RevenueMatches()
    {
        using var provider = Program.ConfigureServices(_dir);
        new DataSeeder(provider.GetRequiredService<IMenuService>(), provider.GetRequiredService<ICustomerService>()).SeedIfEmpty();
        var orders = provider.GetRequiredService<IOrderService>();
        var order = orders.CreateOrder(1, new[] { new OrderLine(2, 1) }, false);
        orders.ChangeStatus(order.Id, OrderStatus.Cooking);
        orders.ChangeStatus(order.Id, OrderStatus.Completed);

        var reports = provider.GetRequiredService<IReportService>();
        Assert.Equal(590m, reports.GetRevenue(DateTime.Today, DateTime.Now.AddMinutes(1)));
    }
}
