using PizzeriaApp.BusinessLogic.Exceptions;
using PizzeriaApp.BusinessLogic.Services;
using Xunit;

namespace PizzeriaApp.Tests;

public class CustomerServiceTests
{
    private readonly CustomerService _service = new(new InMemoryCustomerRepository());

    [Theory] // ТК-10
    [InlineData("8 916 123 45 67", "+79161234567")]
    [InlineData("+7 (916) 123-45-67", "+79161234567")]
    public void NormalizePhone_ValidFormats_ReturnsCanonical(string input, string expected) =>
        Assert.Equal(expected, CustomerService.NormalizePhone(input));

    [Theory] // ТК-11
    [InlineData("12345")]
    [InlineData("")]
    [InlineData("+1 916 123 45 67")]
    public void NormalizePhone_Invalid_ThrowsValidation(string input) =>
        Assert.Throws<ValidationException>(() => CustomerService.NormalizePhone(input));

    [Fact] // ТК-12
    public void Register_DuplicatePhone_ThrowsValidation()
    {
        _service.Register("Иванов И.И.", "89161234567", "адрес");
        Assert.Throws<ValidationException>(() => _service.Register("Петров П.П.", "+7 916 123-45-67", "другой"));
    }

    [Fact] // ТК-13
    public void GetById_Unknown_ThrowsNotFound() =>
        Assert.Throws<EntityNotFoundException>(() => _service.GetById(7));
}
