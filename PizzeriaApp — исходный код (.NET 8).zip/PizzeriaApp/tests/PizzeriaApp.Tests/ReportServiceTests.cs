using PizzeriaApp.BusinessLogic.Services;
using PizzeriaApp.DataAccess.Entities;
using Xunit;

namespace PizzeriaApp.Tests;

public class ReportServiceTests
{
    [Fact] // ТК-26
    public void GetRevenue_CountsOnlyCompletedOrders()
    {
        var repo = new InMemoryOrderRepository();
        repo.Add(new Order { CreatedAt = DateTime.Now, Status = OrderStatus.Completed, Total = 1000m });
        repo.Add(new Order { CreatedAt = DateTime.Now, Status = OrderStatus.Cancelled, Total = 500m });
        var service = new ReportService(repo);
        Assert.Equal(1000m, service.GetRevenue(DateTime.Today, DateTime.Now.AddMinutes(1)));
    }

    [Fact] // ТК-27
    public void GetTopPizzas_AggregatesByName()
    {
        var repo = new InMemoryOrderRepository();
        repo.Add(new Order
        {
            CreatedAt = DateTime.Now,
            Status = OrderStatus.Completed,
            Items = { new OrderItem { PizzaName = "Маргарита", Quantity = 2, UnitPrice = 450m }, new OrderItem { PizzaName = "Пепперони", Quantity = 1, UnitPrice = 590m } }
        });
        repo.Add(new Order
        {
            CreatedAt = DateTime.Now,
            Status = OrderStatus.Completed,
            Items = { new OrderItem { PizzaName = "Маргарита", Quantity = 3, UnitPrice = 450m } }
        });
        var top = new ReportService(repo).GetTopPizzas(DateTime.Today, DateTime.Now.AddMinutes(1), 1);
        Assert.Single(top);
        Assert.Equal("Маргарита", top[0].PizzaName);
        Assert.Equal(5, top[0].Quantity);
        Assert.Equal(2250m, top[0].Revenue);
    }
}
