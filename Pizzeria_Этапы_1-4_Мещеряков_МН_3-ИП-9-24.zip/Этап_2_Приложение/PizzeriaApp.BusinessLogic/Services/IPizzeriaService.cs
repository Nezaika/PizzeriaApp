using PizzeriaApp.DataAccess.Models;

namespace PizzeriaApp.BusinessLogic.Services;

public interface IPizzeriaService
{
    Task<List<Pizza>> GetPizzasAsync();
    Task<List<CustomerOrder>> GetOrdersAsync();
    Task CreateOrderAsync(string customerName, string phone, string address, Pizza pizza, int quantity);
    Task ChangeOrderStatusAsync(CustomerOrder order, string status);
}
