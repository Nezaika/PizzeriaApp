using System.Diagnostics;
using PizzeriaApp.BusinessLogic.Exceptions;
using PizzeriaApp.DataAccess.Models;
using PizzeriaApp.DataAccess.Repositories;

namespace PizzeriaApp.BusinessLogic.Services;

public class PizzeriaService : IPizzeriaService
{
    private readonly IPizzaRepository _pizzas;
    private readonly IOrderRepository _orders;

    public PizzeriaService(IPizzaRepository pizzas, IOrderRepository orders)
    {
        _pizzas = pizzas;
        _orders = orders;
    }

    public Task<List<Pizza>> GetPizzasAsync() => _pizzas.GetAllAsync();
    public Task<List<CustomerOrder>> GetOrdersAsync() => _orders.GetAllAsync();

    public async Task CreateOrderAsync(string customerName, string phone, string address, Pizza pizza, int quantity)
    {
        if (string.IsNullOrWhiteSpace(customerName))
            throw new OrderValidationException("Укажите имя клиента.");
        if (string.IsNullOrWhiteSpace(phone))
            throw new OrderValidationException("Укажите номер телефона.");
        if (string.IsNullOrWhiteSpace(address))
            throw new OrderValidationException("Укажите адрес доставки.");
        if (pizza is null || pizza.Id <= 0)
            throw new OrderValidationException("Выберите пиццу из меню.");
        if (quantity < 1 || quantity > 20)
            throw new OrderValidationException("Количество должно быть от 1 до 20.");

        var order = new CustomerOrder
        {
            CustomerName = customerName.Trim(),
            Phone = phone.Trim(),
            Address = address.Trim(),
            Items = $"{pizza.Name} × {quantity}",
            Total = pizza.Price * quantity,
            Status = "Новый",
            CreatedAt = DateTime.Now
        };
        Debug.WriteLine($"[BLL] Создание заказа для {order.CustomerName}; сумма={order.Total}");
        Trace.WriteLine($"[BLL] Создание заказа: {order.Items}; сумма={order.Total}");
        await _orders.AddAsync(order);
    }

    public async Task ChangeOrderStatusAsync(CustomerOrder order, string status)
    {
        var allowed = new[] { "Новый", "Готовится", "В доставке", "Выполнен", "Отменён" };
        if (!allowed.Contains(status))
            throw new OrderValidationException("Выбран неизвестный статус заказа.");
        order.Status = status;
        await _orders.UpdateAsync(order);
    }
}
