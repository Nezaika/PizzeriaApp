namespace PizzeriaApp.BusinessLogic.Exceptions;

public sealed class OrderValidationException : Exception
{
    public OrderValidationException(string message) : base(message) { }
}
