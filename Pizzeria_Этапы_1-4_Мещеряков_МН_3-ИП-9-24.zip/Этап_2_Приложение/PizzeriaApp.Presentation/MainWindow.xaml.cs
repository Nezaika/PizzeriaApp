using System.Windows;
using System.Windows.Controls;
using Microsoft.Extensions.DependencyInjection;
using PizzeriaApp.BusinessLogic.Exceptions;
using PizzeriaApp.BusinessLogic.Services;
using PizzeriaApp.DataAccess.Models;

namespace PizzeriaApp.Presentation;

public partial class MainWindow : Window
{
    private readonly PizzeriaService _service;
    private readonly IServiceScope _scope;

    public MainWindow()
    {
        InitializeComponent();
        _scope = App.Services.CreateScope();
        _service = _scope.ServiceProvider.GetRequiredService<PizzeriaService>();
        Closed += (_, _) => _scope.Dispose();
        QuantityBox.TextChanged += (_, _) => UpdateTotal();
        Loaded += async (_, _) => await LoadDataAsync();
    }

    private async Task LoadDataAsync()
    {
        try
        {
            PizzasGrid.ItemsSource = await _service.GetPizzasAsync();
            PizzaCombo.ItemsSource = (await _service.GetPizzasAsync()).Where(p => p.IsAvailable).ToList();
            OrdersGrid.ItemsSource = await _service.GetOrdersAsync();
            UpdateTotal();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Не удалось загрузить данные: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private async void RefreshPizzas_Click(object sender, RoutedEventArgs e) => await LoadDataAsync();
    private async void RefreshOrders_Click(object sender, RoutedEventArgs e) => OrdersGrid.ItemsSource = await _service.GetOrdersAsync();
    private void PizzaCombo_SelectionChanged(object sender, SelectionChangedEventArgs e) => UpdateTotal();

    private void UpdateTotal()
    {
        if (PizzaCombo?.SelectedItem is Pizza pizza &&
            int.TryParse(QuantityBox?.Text, out var quantity) && quantity > 0)
            TotalText.Text = $"{pizza.Price * quantity:N2} ₽";
        else if (TotalText is not null) TotalText.Text = "0 ₽";
    }

    private async void CreateOrder_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (PizzaCombo.SelectedItem is not Pizza pizza)
                throw new OrderValidationException("Выберите пиццу из меню.");
            if (!int.TryParse(QuantityBox.Text, out var quantity))
                throw new OrderValidationException("Количество должно быть целым числом.");

            await _service.CreateOrderAsync(CustomerNameBox.Text, PhoneBox.Text, AddressBox.Text, pizza, quantity);
            MessageBox.Show("Заказ успешно сохранён.", "Готово", MessageBoxButton.OK, MessageBoxImage.Information);
            await LoadDataAsync();
            ClearFields();
        }
        catch (OrderValidationException ex)
        {
            MessageBox.Show(ex.Message, "Проверьте данные", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Не удалось создать заказ: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void Clear_Click(object sender, RoutedEventArgs e) => ClearFields();

    private void ClearFields()
    {
        CustomerNameBox.Clear();
        PhoneBox.Clear();
        AddressBox.Clear();
        QuantityBox.Text = "1";
        PizzaCombo.SelectedIndex = -1;
        UpdateTotal();
    }
}
