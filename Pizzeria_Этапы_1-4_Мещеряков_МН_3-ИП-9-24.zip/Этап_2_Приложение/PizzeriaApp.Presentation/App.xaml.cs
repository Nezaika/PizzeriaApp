using System.Diagnostics;
using System.IO;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using PizzeriaApp.BusinessLogic.Services;
using PizzeriaApp.DataAccess;
using PizzeriaApp.DataAccess.Repositories;

namespace PizzeriaApp.Presentation;

public partial class App : System.Windows.Application
{
    public static ServiceProvider Services { get; private set; } = null!;

    protected override void OnStartup(System.Windows.StartupEventArgs e)
    {
        base.OnStartup(e);
        var services = new ServiceCollection();
        var dataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "PizzeriaApp");
        Directory.CreateDirectory(dataDir);
        var dbPath = Path.Combine(dataDir, "pizzeria.db");

        services.AddDbContext<PizzeriaContext>(options => options.UseSqlite($"Data Source={dbPath}"));
        services.AddScoped<IPizzaRepository, PizzaRepository>();
        services.AddScoped<IOrderRepository, OrderRepository>();
        services.AddScoped<PizzeriaService>();
        services.AddScoped<PizzeriaApp.BusinessLogic.Services.IPizzeriaService>(sp => sp.GetRequiredService<PizzeriaService>());
        Services = services.BuildServiceProvider();

        using var scope = Services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<PizzeriaContext>();
        db.Database.EnsureCreated();
        Trace.Listeners.Add(new TextWriterTraceListener(Path.Combine(dataDir, "pizzeria.log")));
        Trace.AutoFlush = true;
        Trace.WriteLine($"[APP] Запуск приложения {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
    }

    protected override void OnExit(System.Windows.ExitEventArgs e)
    {
        Trace.WriteLine($"[APP] Завершение приложения {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        Trace.Flush();
        Services?.Dispose();
        base.OnExit(e);
    }
}
