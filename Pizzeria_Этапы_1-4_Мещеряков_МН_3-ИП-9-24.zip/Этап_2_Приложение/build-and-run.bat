@echo off
echo Restore packages...
dotnet restore PizzeriaApp.sln
if errorlevel 1 goto error
echo Build solution...
dotnet build PizzeriaApp.sln
if errorlevel 1 goto error
echo Starting WPF app...
dotnet run --project PizzeriaApp.Presentation\PizzeriaApp.Presentation.csproj
goto end
:error
echo Build failed. Check that .NET 8 SDK is installed and NuGet is available.
:end
pause
