namespace PizzeriaApp.DataAccess.Models;

public class CustomerOrder
{
    public int Id { get; set; }
    public string CustomerName { get; set; } = "";
    public string Phone { get; set; } = "";
    public string Address { get; set; } = "";
    public string Items { get; set; } = "";
    public decimal Total { get; set; }
    public string Status { get; set; } = "Новый";
    public DateTime CreatedAt { get; set; } = DateTime.Now;
}
