using Microsoft.EntityFrameworkCore;
using PizzeriaApp.DataAccess.Models;

namespace PizzeriaApp.DataAccess;

public class PizzeriaContext : DbContext
{
    public DbSet<Pizza> Pizzas => Set<Pizza>();
    public DbSet<CustomerOrder> Orders => Set<CustomerOrder>();

    public PizzeriaContext(DbContextOptions<PizzeriaContext> options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Pizza>().Property(p => p.Price).HasPrecision(10, 2);
        modelBuilder.Entity<CustomerOrder>().Property(o => o.Total).HasPrecision(10, 2);
        modelBuilder.Entity<Pizza>().HasData(
            new Pizza { Id = 1, Name = "Маргарита", Description = "Томатный соус, моцарелла, базилик", Price = 490m, IsAvailable = true },
            new Pizza { Id = 2, Name = "Пепперони", Description = "Моцарелла, пепперони, томатный соус", Price = 590m, IsAvailable = true },
            new Pizza { Id = 3, Name = "Четыре сыра", Description = "Моцарелла, дорблю, пармезан, чеддер", Price = 650m, IsAvailable = true },
            new Pizza { Id = 4, Name = "Ветчина и грибы", Description = "Ветчина, шампиньоны, сыр", Price = 620m, IsAvailable = true }
        );
    }
}
