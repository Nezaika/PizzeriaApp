using Microsoft.EntityFrameworkCore;
using PizzeriaApp.DataAccess.Models;

namespace PizzeriaApp.DataAccess.Repositories;

public class PizzaRepository : IPizzaRepository
{
    private readonly PizzeriaContext _db;
    public PizzaRepository(PizzeriaContext db) => _db = db;

    public Task<List<Pizza>> GetAllAsync(CancellationToken cancellationToken = default) =>
        _db.Pizzas.AsNoTracking().OrderBy(p => p.Name).ToListAsync(cancellationToken);

    public Task<Pizza?> GetByIdAsync(int id, CancellationToken cancellationToken = default) =>
        _db.Pizzas.AsNoTracking().FirstOrDefaultAsync(p => p.Id == id, cancellationToken);

    public async Task AddAsync(Pizza pizza, CancellationToken cancellationToken = default)
    {
        _db.Pizzas.Add(pizza);
        await _db.SaveChangesAsync(cancellationToken);
    }

    public async Task UpdateAsync(Pizza pizza, CancellationToken cancellationToken = default)
    {
        _db.Pizzas.Update(pizza);
        await _db.SaveChangesAsync(cancellationToken);
    }

    public async Task DeleteAsync(int id, CancellationToken cancellationToken = default)
    {
        var entity = await _db.Pizzas.FindAsync(new object[] { id }, cancellationToken);
        if (entity is null) return;
        _db.Pizzas.Remove(entity);
        await _db.SaveChangesAsync(cancellationToken);
    }
}
