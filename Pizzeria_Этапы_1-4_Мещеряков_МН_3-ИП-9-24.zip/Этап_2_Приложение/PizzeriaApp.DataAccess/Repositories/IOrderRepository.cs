using PizzeriaApp.DataAccess.Models;

namespace PizzeriaApp.DataAccess.Repositories;

public interface IOrderRepository
{
    Task<List<CustomerOrder>> GetAllAsync(CancellationToken cancellationToken = default);
    Task AddAsync(CustomerOrder order, CancellationToken cancellationToken = default);
    Task UpdateAsync(CustomerOrder order, CancellationToken cancellationToken = default);
}
