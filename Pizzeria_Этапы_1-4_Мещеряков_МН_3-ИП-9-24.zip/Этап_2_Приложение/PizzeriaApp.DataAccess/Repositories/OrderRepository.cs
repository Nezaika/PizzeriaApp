using Microsoft.EntityFrameworkCore;
using PizzeriaApp.DataAccess.Models;

namespace PizzeriaApp.DataAccess.Repositories;

public class OrderRepository : IOrderRepository
{
    private readonly PizzeriaContext _db;
    public OrderRepository(PizzeriaContext db) => _db = db;

    public Task<List<CustomerOrder>> GetAllAsync(CancellationToken cancellationToken = default) =>
        _db.Orders.AsNoTracking().OrderByDescending(o => o.CreatedAt).ToListAsync(cancellationToken);

    public async Task AddAsync(CustomerOrder order, CancellationToken cancellationToken = default)
    {
        _db.Orders.Add(order);
        await _db.SaveChangesAsync(cancellationToken);
    }

    public async Task UpdateAsync(CustomerOrder order, CancellationToken cancellationToken = default)
    {
        _db.Orders.Update(order);
        await _db.SaveChangesAsync(cancellationToken);
    }
}
