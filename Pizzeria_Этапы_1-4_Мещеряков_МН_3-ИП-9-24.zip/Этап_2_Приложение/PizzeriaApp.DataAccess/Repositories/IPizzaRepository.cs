using PizzeriaApp.DataAccess.Models;

namespace PizzeriaApp.DataAccess.Repositories;

public interface IPizzaRepository
{
    Task<List<Pizza>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<Pizza?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task AddAsync(Pizza pizza, CancellationToken cancellationToken = default);
    Task UpdateAsync(Pizza pizza, CancellationToken cancellationToken = default);
    Task DeleteAsync(int id, CancellationToken cancellationToken = default);
}
