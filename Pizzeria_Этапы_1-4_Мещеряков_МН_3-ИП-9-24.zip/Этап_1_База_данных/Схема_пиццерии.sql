/*
Этап 1. Проектирование структуры данных для информационной системы пиццерии
Студент: Мещеряков М.Н. | Группа: 3-ИП-9-24
СУБД: Microsoft SQL Server 2019/2022 (T-SQL)

Запуск: открыть в SSMS и выполнить целиком в отдельной учебной базе.
Скрипт удаляет и пересоздаёт только таблицы учебной схемы ниже.
Не запускайте в рабочей базе.
*/
SET NOCOUNT ON;
GO
IF DB_ID(N'PizzeriaStudyDB') IS NULL CREATE DATABASE PizzeriaStudyDB;
GO
USE PizzeriaStudyDB;
GO
/* Перезапуск в правильном порядке: триггеры/таблицы удаляются только в учебной БД. */
DROP TRIGGER IF EXISTS dbo.trg_OrderItems_Max20_ActiveMenu;
DROP TRIGGER IF EXISTS dbo.trg_OrderItems_Validate;
DROP TRIGGER IF EXISTS dbo.trg_MenuItems_Audit_InsertUpdate;
DROP TRIGGER IF EXISTS dbo.trg_MenuItems_InsteadOfDelete;
DROP TRIGGER IF EXISTS dbo.trg_PizzaOrders_Audit;
GO
DROP TABLE IF EXISTS dbo.AuditChanges;
DROP TABLE IF EXISTS dbo.OrderItems;
DROP TABLE IF EXISTS dbo.PizzaOrders;
DROP TABLE IF EXISTS dbo.MenuItems;
GO
CREATE TABLE dbo.MenuItems (
    MenuItemID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_MenuItems PRIMARY KEY,
    ItemName NVARCHAR(100) NOT NULL,
    Category NVARCHAR(50) NOT NULL,
    Description NVARCHAR(250) NULL,
    Price DECIMAL(10,2) NOT NULL,
    IsArchived BIT NOT NULL CONSTRAINT DF_MenuItems_IsArchived DEFAULT (0),
    CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_MenuItems_CreatedAt DEFAULT (SYSDATETIME()),
    CONSTRAINT UQ_MenuItems_ItemName UNIQUE(ItemName),
    CONSTRAINT CK_MenuItems_Price CHECK (Price > 0)
);
CREATE TABLE dbo.PizzaOrders (
    OrderID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_PizzaOrders PRIMARY KEY,
    CustomerName NVARCHAR(100) NOT NULL,
    Phone NVARCHAR(20) NULL,
    DeliveryAddress NVARCHAR(250) NULL,
    OrderDate DATETIME2(0) NOT NULL CONSTRAINT DF_PizzaOrders_OrderDate DEFAULT (SYSDATETIME()),
    Status NVARCHAR(30) NOT NULL CONSTRAINT DF_PizzaOrders_Status DEFAULT (N'Принят'),
    CONSTRAINT CK_PizzaOrders_Status CHECK (Status IN (N'Принят',N'Готовится',N'Готов',N'Доставляется',N'Выдан',N'Отменён'))
);
CREATE TABLE dbo.OrderItems (
    OrderItemID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_OrderItems PRIMARY KEY,
    OrderID INT NOT NULL,
    MenuItemID INT NOT NULL,
    Quantity INT NOT NULL CONSTRAINT DF_OrderItems_Quantity DEFAULT (1),
    UnitPrice DECIMAL(10,2) NOT NULL,
    CONSTRAINT FK_OrderItems_PizzaOrders FOREIGN KEY (OrderID) REFERENCES dbo.PizzaOrders(OrderID),
    CONSTRAINT FK_OrderItems_MenuItems FOREIGN KEY (MenuItemID) REFERENCES dbo.MenuItems(MenuItemID),
    CONSTRAINT CK_OrderItems_Quantity CHECK (Quantity > 0),
    CONSTRAINT CK_OrderItems_UnitPrice CHECK (UnitPrice > 0)
);
CREATE TABLE dbo.AuditChanges (
    AuditID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuditChanges PRIMARY KEY,
    TableName SYSNAME NOT NULL,
    Operation NVARCHAR(10) NOT NULL,
    RecordID INT NULL,
    OldData NVARCHAR(MAX) NULL,
    NewData NVARCHAR(MAX) NULL,
    DbUser SYSNAME NOT NULL CONSTRAINT DF_AuditChanges_DbUser DEFAULT (ORIGINAL_LOGIN()),
    ChangedAt DATETIME2(3) NOT NULL CONSTRAINT DF_AuditChanges_ChangedAt DEFAULT (SYSDATETIME())
);
CREATE INDEX IX_PizzaOrders_OrderDate ON dbo.PizzaOrders(OrderDate);
CREATE INDEX IX_PizzaOrders_Status ON dbo.PizzaOrders(Status);
CREATE INDEX IX_OrderItems_OrderID ON dbo.OrderItems(OrderID);
GO
INSERT dbo.MenuItems(ItemName,Category,Description,Price) VALUES
(N'Маргарита',N'Пицца',N'Томатный соус, моцарелла, базилик',650.00),
(N'Пепперони',N'Пицца',N'Пепперони и моцарелла',800.00),
(N'Четыре сыра',N'Пицца',N'Смесь четырёх сыров',890.00),
(N'Грибная',N'Пицца',N'Грибы, сыр, сливочный соус',740.00),
(N'Кола 0,5 л',N'Напиток',N'Газированный напиток',150.00);
INSERT dbo.PizzaOrders(CustomerName,Phone,DeliveryAddress,Status) VALUES
(N'Иван Петров',N'+79990000001',N'ул. Примерная, 1',N'Принят'),
(N'Анна Смирнова',N'+79990000002',N'ул. Учебная, 5',N'Готовится');
INSERT dbo.OrderItems(OrderID,MenuItemID,Quantity,UnitPrice) VALUES
(1,1,2,650.00),(1,5,1,150.00),(2,2,1,800.00);
GO
CREATE OR ALTER VIEW dbo.v_OrderTotals AS
SELECT o.OrderID,o.CustomerName,o.OrderDate,o.Status,
       CAST(SUM(CAST(oi.Quantity AS DECIMAL(10,0))*oi.UnitPrice) AS DECIMAL(18,2)) AS TotalAmount
FROM dbo.PizzaOrders o
JOIN dbo.OrderItems oi ON oi.OrderID=o.OrderID
GROUP BY o.OrderID,o.CustomerName,o.OrderDate,o.Status;
GO
/* Контрольные запросы */
SELECT * FROM dbo.MenuItems ORDER BY MenuItemID;
SELECT * FROM dbo.PizzaOrders ORDER BY OrderID;
SELECT * FROM dbo.OrderItems ORDER BY OrderID,OrderItemID;
SELECT * FROM dbo.v_OrderTotals ORDER BY OrderID;
DBCC CHECKCONSTRAINTS WITH ALL_CONSTRAINTS;
GO
