@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ==================================================
echo  Пиццерия — Мещеряков М.Н., группа 3-ИП-9-24
echo  Сборка приложения, тесты и запуск WPF
echo ==================================================
where dotnet >nul 2>nul
if errorlevel 1 (
  echo ОШИБКА: не найден .NET SDK.
  echo Установите .NET 8 SDK: https://dotnet.microsoft.com/download/dotnet/8.0
  pause
  exit /b 1
)
echo.
echo [1/4] Восстановление пакетов приложения...
dotnet restore "Этап_2_Приложение\PizzeriaApp.sln"
if errorlevel 1 goto failed
echo.
echo [2/4] Сборка приложения...
dotnet build "Этап_2_Приложение\PizzeriaApp.sln" --configuration Release --no-restore
if errorlevel 1 goto failed
echo.
echo [3/4] Восстановление и запуск тестов...
dotnet test "Этап_3_Тестирование\Pizzeria.Testing.sln" --configuration Release
if errorlevel 1 goto failed
echo.
echo [4/4] Запуск приложения (требуется Windows, WPF)...
dotnet run --project "Этап_2_Приложение\PizzeriaApp.Presentation\PizzeriaApp.Presentation.csproj" --configuration Release --no-build
if errorlevel 1 goto failed
echo.
echo Работа завершена.
pause
exit /b 0
:failed
echo.
echo ОШИБКА: один из этапов завершился с ошибкой. Проверьте текст выше.
pause
exit /b 1
