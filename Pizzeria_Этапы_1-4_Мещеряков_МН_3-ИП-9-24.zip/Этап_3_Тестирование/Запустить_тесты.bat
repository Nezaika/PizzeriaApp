@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo ===============================================
echo   Этап 3 — тестирование системы пиццерии
echo   Мещеряков Марк Николаевич, 3-ИП-9-24
echo ===============================================
echo.
where dotnet >nul 2>nul
if errorlevel 1 (
  echo ОШИБКА: .NET SDK не найден.
  echo Установи .NET 8 SDK с https://dotnet.microsoft.com/download/dotnet/8.0
  echo Затем закрой и заново открой это окно и запусти файл ещё раз.
  echo.
  pause
  exit /b 1
)
dotnet --version
echo.
echo [1/2] Восстановление пакетов...
dotnet restore Pizzeria.Testing.sln
if errorlevel 1 goto failed
echo.
echo [2/2] Запуск модульных и интеграционных тестов...
dotnet test Pizzeria.Testing.sln --configuration Release --no-restore
if errorlevel 1 goto failed
echo.
echo УСПЕХ: все тесты завершились без ошибок.
echo Чтобы получить покрытие кода, запусти:
echo dotnet test Pizzeria.Testing.sln --configuration Release --collect:"XPlat Code Coverage"
echo.
pause
exit /b 0
:failed
echo.
echo ТЕСТЫ НЕ ЗАВЕРШИЛИСЬ УСПЕШНО. Прочитай сообщение об ошибке выше.
echo Если ошибка связана с сетью, проверь интернет и повтори запуск.
pause
exit /b 1
