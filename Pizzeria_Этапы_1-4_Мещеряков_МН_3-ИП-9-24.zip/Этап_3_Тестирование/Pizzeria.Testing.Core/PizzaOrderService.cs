namespace Pizzeria.Testing.Core;

public sealed record Pizza(string Name, decimal Price);
public sealed record OrderLine(Pizza Pizza, int Quantity);

public static class OrderRules
{
    public static decimal CalculateTotal(IEnumerable<OrderLine> lines)
    {
        ArgumentNullException.ThrowIfNull(lines);
        var items = lines.ToList();
        if (items.Count == 0)
            throw new ArgumentException("Заказ должен содержать хотя бы одну позицию.", nameof(lines));

        decimal total = 0;
        foreach (var line in items)
        {
            if (string.IsNullOrWhiteSpace(line.Pizza.Name))
                throw new ArgumentException("Название пиццы не может быть пустым.");
            if (line.Pizza.Price <= 0)
                throw new ArgumentOutOfRangeException(nameof(line.Pizza.Price), "Цена должна быть положительной.");
            if (line.Quantity <= 0)
                throw new ArgumentOutOfRangeException(nameof(line.Quantity), "Количество должно быть больше нуля.");
            total += line.Pizza.Price * line.Quantity;
        }
        return total;
    }
}

public interface IOrderRepository
{
    void Add(Order order);
    IReadOnlyList<Order> GetAll();
}

public sealed record Order(int Id, string CustomerName, IReadOnlyList<OrderLine> Lines);

public sealed class OrderService(IOrderRepository repository)
{
    public Order Create(Order order)
    {
        if (order.Id <= 0) throw new ArgumentException("ID заказа должен быть положительным.");
        if (string.IsNullOrWhiteSpace(order.CustomerName)) throw new ArgumentException("Укажите имя клиента.");
        _ = OrderRules.CalculateTotal(order.Lines);
        if (repository.GetAll().Any(x => x.Id == order.Id))
            throw new InvalidOperationException("Заказ с таким ID уже существует.");
        repository.Add(order);
        return order;
    }
}
