using Pizzeria.Testing.Core;
using Xunit;

namespace Pizzeria.Tests;

public class PizzaOrderServiceTests
{
    [Fact]
    public void CalculateTotal_MultiplePizzas_ReturnsCorrectTotal()
    {
        var lines = new[] { new OrderLine(new Pizza("Маргарита", 650m), 2),
                            new OrderLine(new Pizza("Пепперони", 800m), 1) };
        Assert.Equal(2100m, OrderRules.CalculateTotal(lines));
    }

    [Fact]
    public void CalculateTotal_EmptyOrder_Throws()
        => Assert.Throws<ArgumentException>(() => OrderRules.CalculateTotal(Array.Empty<OrderLine>()));

    [Theory]
    [InlineData(0)]
    [InlineData(-1)]
    public void CalculateTotal_NonPositiveQuantity_Throws(int quantity)
        => Assert.Throws<ArgumentOutOfRangeException>(() =>
            OrderRules.CalculateTotal(new[] { new OrderLine(new Pizza("Маргарита", 650m), quantity) }));

    [Theory]
    [InlineData(0)]
    [InlineData(-10)]
    public void CalculateTotal_NonPositivePrice_Throws(decimal price)
        => Assert.Throws<ArgumentOutOfRangeException>(() =>
            OrderRules.CalculateTotal(new[] { new OrderLine(new Pizza("Маргарита", price), 1) }));

    [Fact]
    public void CalculateTotal_OnePizza_ReturnsItsPrice()
        => Assert.Equal(650m, OrderRules.CalculateTotal(
            new[] { new OrderLine(new Pizza("Маргарита", 650m), 1) }));
}
