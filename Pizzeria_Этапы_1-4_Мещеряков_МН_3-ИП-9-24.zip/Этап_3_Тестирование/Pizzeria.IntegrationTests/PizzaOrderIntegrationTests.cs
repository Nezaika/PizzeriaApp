using Pizzeria.Testing.Core;
using Xunit;

namespace Pizzeria.IntegrationTests;

public class PizzaOrderIntegrationTests
{
    [Fact]
    public void Create_ValidOrder_IsSavedAndReadable()
    {
        var repository = new MemoryOrderRepository();
        var service = new OrderService(repository);
        var order = new Order(1, "Иван", new[] { new OrderLine(new Pizza("Маргарита", 650m), 2) });

        service.Create(order);

        Assert.Contains(repository.GetAll(), x => x.Id == 1 && x.CustomerName == "Иван");
        Assert.Equal(1300m, OrderRules.CalculateTotal(repository.GetAll()[0].Lines));
    }

    [Fact]
    public void Create_DuplicateId_IsRejectedAndNotSaved()
    {
        var repository = new MemoryOrderRepository();
        var service = new OrderService(repository);
        service.Create(new Order(1, "Иван", new[] { new OrderLine(new Pizza("Маргарита", 650m), 1) }));

        Assert.Throws<InvalidOperationException>(() =>
            service.Create(new Order(1, "Анна", new[] { new OrderLine(new Pizza("Пепперони", 800m), 1) })));
        Assert.Single(repository.GetAll());
    }

    private sealed class MemoryOrderRepository : IOrderRepository
    {
        private readonly List<Order> _orders = [];
        public void Add(Order order) => _orders.Add(order);
        public IReadOnlyList<Order> GetAll() => _orders.ToList();
    }
}
