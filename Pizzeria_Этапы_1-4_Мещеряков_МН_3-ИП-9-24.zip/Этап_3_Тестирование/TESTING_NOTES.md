# Запуск тестов

## Windows — самый простой способ

1. Установить .NET 8 SDK: https://dotnet.microsoft.com/download/dotnet/8.0
2. Распаковать весь ZIP в папку.
3. Запустить `Запустить_тесты.bat` двойным щелчком. Для первого восстановления NuGet-пакетов требуется интернет.

## Команды вручную

Из папки, где находится `Pizzeria.Testing.sln`:

```powershell
dotnet --version
dotnet restore Pizzeria.Testing.sln
dotnet test Pizzeria.Testing.sln --configuration Release
```

Отчёт покрытия:

```powershell
dotnet test Pizzeria.Testing.sln --configuration Release --collect:"XPlat Code Coverage"
```

Файлы покрытия будут находиться в каталогах `TestResults`. Не указывай процент покрытия до фактического запуска. Интеграционные тесты используют тестовый репозиторий в памяти, а не реальную БД проекта этапа 2.
