﻿/*
Этап 4. Разработка триггеров для автоматизации работы БД
Тема: Пиццерия
Студент: Мещеряков Марк Николаевич, группа 3-ИП-9-24
СУБД: Microsoft SQL Server 2019/2022, T-SQL

ВНИМАНИЕ:
Скрипт самодостаточный для учебной проверки в отдельной тестовой БД.
Если на этапах 1–3 уже существуют таблицы с другими именами/полями,
адаптируйте имена таблиц и столбцов перед объединением с основной БД.
Запускайте в SSMS в тестовой базе данных.
*/

SET NOCOUNT ON;
GO

/* Демонстрационные таблицы: создаются только если их ещё нет. */
IF OBJECT_ID(N'dbo.MenuItems', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.MenuItems
    (
        MenuItemID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_MenuItems PRIMARY KEY,
        ItemName NVARCHAR(100) NOT NULL,
        Category NVARCHAR(50) NOT NULL,
        Price DECIMAL(10,2) NOT NULL,
        IsArchived BIT NOT NULL CONSTRAINT DF_MenuItems_IsArchived DEFAULT (0),
        CreatedAt DATETIME2(0) NOT NULL CONSTRAINT DF_MenuItems_CreatedAt DEFAULT (SYSDATETIME()),
        CONSTRAINT CK_MenuItems_Price CHECK (Price > 0)
    );
END;
GO

IF OBJECT_ID(N'dbo.PizzaOrders', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.PizzaOrders
    (
        OrderID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_PizzaOrders PRIMARY KEY,
        CustomerName NVARCHAR(100) NOT NULL,
        OrderDate DATETIME2(0) NOT NULL CONSTRAINT DF_PizzaOrders_OrderDate DEFAULT (SYSDATETIME()),
        Status NVARCHAR(30) NOT NULL CONSTRAINT DF_PizzaOrders_Status DEFAULT (N'Принят')
    );
END;
GO

IF OBJECT_ID(N'dbo.OrderItems', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.OrderItems
    (
        OrderItemID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_OrderItems PRIMARY KEY,
        OrderID INT NOT NULL,
        MenuItemID INT NOT NULL,
        Quantity INT NOT NULL CONSTRAINT DF_OrderItems_Quantity DEFAULT (1),
        UnitPrice DECIMAL(10,2) NOT NULL,
        CONSTRAINT FK_OrderItems_PizzaOrders FOREIGN KEY (OrderID) REFERENCES dbo.PizzaOrders(OrderID),
        CONSTRAINT FK_OrderItems_MenuItems FOREIGN KEY (MenuItemID) REFERENCES dbo.MenuItems(MenuItemID),
        CONSTRAINT CK_OrderItems_Quantity CHECK (Quantity > 0),
        CONSTRAINT CK_OrderItems_UnitPrice CHECK (UnitPrice > 0)
    );
END;
GO

IF OBJECT_ID(N'dbo.AuditChanges', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AuditChanges
    (
        AuditID BIGINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_AuditChanges PRIMARY KEY,
        TableName SYSNAME NOT NULL,
        Operation NVARCHAR(10) NOT NULL,
        RecordID INT NULL,
        OldData NVARCHAR(MAX) NULL,
        NewData NVARCHAR(MAX) NULL,
        DbUser SYSNAME NOT NULL CONSTRAINT DF_AuditChanges_DbUser DEFAULT (ORIGINAL_LOGIN()),
        ChangedAt DATETIME2(3) NOT NULL CONSTRAINT DF_AuditChanges_ChangedAt DEFAULT (SYSDATETIME())
    );
END;
GO

/* AFTER INSERT/UPDATE: аудит меню. Сопоставление deleted/inserted по первичному ключу.
   INSERT и UPDATE поддерживают многострочные операции. */
CREATE OR ALTER TRIGGER dbo.trg_MenuItems_Audit_InsertUpdate
ON dbo.MenuItems
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    INSERT dbo.AuditChanges (TableName, Operation, RecordID, OldData, NewData)
    SELECT
        N'MenuItems',
        CASE WHEN d.MenuItemID IS NULL THEN N'INSERT' ELSE N'UPDATE' END,
        i.MenuItemID,
        CASE WHEN d.MenuItemID IS NULL THEN NULL
             ELSE (SELECT d.ItemName AS ItemName, d.Category AS Category, d.Price AS Price,
                          d.IsArchived AS IsArchived FOR JSON PATH, WITHOUT_ARRAY_WRAPPER) END,
        (SELECT i.ItemName AS ItemName, i.Category AS Category, i.Price AS Price,
                i.IsArchived AS IsArchived FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM inserted AS i
    LEFT JOIN deleted AS d ON d.MenuItemID = i.MenuItemID;
END;
GO

/* INSTEAD OF DELETE: физическое удаление позиции меню заменяется архивированием.
   Аудит записывается для каждой строки удаляемого набора. */
CREATE OR ALTER TRIGGER dbo.trg_MenuItems_InsteadOfDelete
ON dbo.MenuItems
INSTEAD OF DELETE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE m
       SET IsArchived = 1
    FROM dbo.MenuItems AS m
    INNER JOIN deleted AS d ON d.MenuItemID = m.MenuItemID
    WHERE m.IsArchived = 0;

    INSERT dbo.AuditChanges (TableName, Operation, RecordID, OldData, NewData)
    SELECT
        N'MenuItems',
        N'ARCHIVE',
        d.MenuItemID,
        (SELECT d.ItemName AS ItemName, d.Category AS Category, d.Price AS Price,
                d.IsArchived AS IsArchived FOR JSON PATH, WITHOUT_ARRAY_WRAPPER),
        (SELECT m.ItemName AS ItemName, m.Category AS Category, m.Price AS Price,
                m.IsArchived AS IsArchived FOR JSON PATH, WITHOUT_ARRAY_WRAPPER)
    FROM deleted AS d
    INNER JOIN dbo.MenuItems AS m ON m.MenuItemID = d.MenuItemID;
END;
GO

/* AFTER INSERT/UPDATE: бизнес-правила состава заказа.
   1) максимум 20 строк OrderItems на заказ;
   2) архивную позицию меню нельзя добавлять в заказ.
   inserted обрабатывается как набор; при нарушении SQL Server откатывает оператор. */
CREATE OR ALTER TRIGGER dbo.trg_OrderItems_Max20_ActiveMenu
ON dbo.OrderItems
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT oi.OrderID
        FROM dbo.OrderItems AS oi
        INNER JOIN (SELECT DISTINCT OrderID FROM inserted) AS affected
            ON affected.OrderID = oi.OrderID
        GROUP BY oi.OrderID
        HAVING COUNT_BIG(*) > 20
    )
    BEGIN
        THROW 50010, N'Нельзя добавить более 20 строк состава в один заказ. Операция отменена.', 1;
    END;

    IF EXISTS
    (
        SELECT 1
        FROM inserted AS i
        INNER JOIN dbo.MenuItems AS m ON m.MenuItemID = i.MenuItemID
        WHERE m.IsArchived = 1
    )
    BEGIN
        THROW 50011, N'Нельзя добавить архивную позицию меню в заказ. Операция отменена.', 1;
    END;
END;
GO

/* Минимальный сценарий проверки. Выполняйте в тестовой БД.
   Повторный запуск тестовых INSERT создаёт новые тестовые записи. */
DECLARE @Pizza1 INT, @Pizza2 INT, @OrderID INT;

INSERT dbo.MenuItems (ItemName, Category, Price)
VALUES (N'Маргарита — тест', N'Пицца', 550.00),
       (N'Пепперони — тест', N'Пицца', 650.00);

SELECT @Pizza1 = MIN(MenuItemID)
FROM dbo.MenuItems WHERE ItemName = N'Маргарита — тест';
SELECT @Pizza2 = MIN(MenuItemID)
FROM dbo.MenuItems WHERE ItemName = N'Пепперони — тест';

INSERT dbo.PizzaOrders (CustomerName) VALUES (N'Тест этапа 4');
SET @OrderID = SCOPE_IDENTITY();

-- Тест 1: допустимая многострочная вставка двух строк состава.
INSERT dbo.OrderItems (OrderID, MenuItemID, Quantity, UnitPrice)
VALUES (@OrderID, @Pizza1, 1, 550.00),
       (@OrderID, @Pizza2, 1, 650.00);

-- Тест 2: UPDATE меню должен создать запись аудита со старыми и новыми данными.
UPDATE dbo.MenuItems SET Price = Price + 10.00 WHERE MenuItemID IN (@Pizza1, @Pizza2);

-- Тест 3: DELETE должен архивировать, а не физически удалять позицию.
DELETE dbo.MenuItems WHERE MenuItemID = @Pizza2;

-- Просмотр результата аудита и состояния меню.
SELECT TOP (100) * FROM dbo.AuditChanges ORDER BY AuditID DESC;
SELECT MenuItemID, ItemName, Price, IsArchived
FROM dbo.MenuItems WHERE MenuItemID IN (@Pizza1, @Pizza2);

-- Негативные тесты (запускайте отдельно, намеренно ожидается ошибка):
-- A) После подготовки заказа с 20 строками попытка добавить 21-ю должна дать 50010.
-- B) Попытка добавить в OrderItems позицию с IsArchived=1 должна дать 50011.
-- Для проверки лимита можно создать отдельный заказ и вставить 21 строку,
-- используя активную позицию меню; весь нарушающий INSERT должен быть отменён.
GO

/* Диагностика установленных триггеров:
SELECT name, is_disabled FROM sys.triggers WHERE parent_id IN
(OBJECT_ID(N'dbo.MenuItems'), OBJECT_ID(N'dbo.OrderItems'));
*/
